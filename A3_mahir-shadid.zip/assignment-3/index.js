const { pid } = require('process')

var mgdb = require('mongodb').MongoClient
var url="mongodb://127.0.0.1:27017/"
mgdb.connect(url, function (err,mymgdb) {
    if(err){
        console.log("DB not connected")
    }else{
        console.log("DB connected")

        //workers_including_me(mymgdb)
        //createcol(mymgdb)
        //products_insert(mymgdb)
        //partner_delete(mymgdb)
        //update_product(mymgdb)
        //create_another_col(mymgdb)
        //workers(mymgdb)
        kon_worker_konta_sell_korse(mymgdb)
    }
})

function workers_including_me(mymgdb){

    //amar supershop er jonno worker inserting function
    var db = mymgdb.db("supershop")
    var col = db.collection("all")

    var data = {role_id:"4",role:"partner",name:"Mushfiq Afnan",phone:"01888504938"}
    col.insertOne(data, function (err) {
        if(err){
            console.log("Not inserted")
        }else{
            console.log("Inserted")
        }
    })

}

function workers(mymgdb){

    var db = mymgdb.db("supershop")
    var col = db.collection("all")
    var sort = {role_id:1}
    col.find().sort(sort).toArray(function (err,res) {
        console.log(res)
    })

}

function createcol(mymgdb){

    var db = mymgdb.db("supershop")

    db.createCollection("products",function (err,res) {

        if(err){
            console.log("Not created")
        }else{
            console.log(res)
        }
        
    })
}

function products_insert(mymgdb){

    var db = mymgdb.db("supershop")
    var col = db.collection("products")

    var data = {pid:"6",name:"Alu",price:"40Tk"}
    var dataobj = data.pid //pid object ta nicchi jeno find kora jay

    col.insertOne(data, function (err) {
       if(err){
           console.log("Insert failed")
       }else{
           console.log("Product inserted")
        }
   })

    //products insert kore show korbe
    var obj={pid:dataobj}
    col.findOne(obj,function (err,res) {
        console.log(res)
    })

}

function partner_delete(mymgdb){

    var db = mymgdb.db("supershop")
    var col = db.collection("all")
    var delobj = {role_id:"4"}
    col.deleteOne(delobj,function (err) {
        if(err){
            console.log("Not deleted")
        }else{
            console.log("Partner Deleted")
        }
    })
    
    //partner delete kore show korbe
    var sort = {role_id:1}
    col.find().sort(sort).toArray(function (err,res) {
        console.log(res)
    })

}

function update_product(mymgdb){

    var db = mymgdb.db("supershop")
    var col = db.collection("products")
    var obj = {pid:"4"}

    
    col.findOne(obj,function (err,result) {
        console.log("Before Update")
        console.log(result)
    })

    var newv = {$set:{name:"sugar",price:"70Tk"}}

    col.updateOne(obj,newv,function (err,res) {
        console.log(res)
    })


    col.findOne(obj,function (err,rest) {
        console.log("After Update")
        console.log(rest)
    })

}

function create_another_col(mymgdb){

    var db = mymgdb.db("supershop")

    db.createCollection("product_sell",function (err,res) {

        if(err){
            console.log("Not created")
        }else{
            console.log(res)
        }
        
    })

}

function kon_worker_konta_sell_korse(mymgdb){

    var db = mymgdb.db("supershop")
    var col = db.collection("product_sell")

    var date = Date()
    var data = {wname: "Y", pname: "sugar", datecolumn: date}

    col.insertOne(data, function (err) {
        if(err){
            console.log("Insert Failed")
        }else{
            console.log("Inserted")
        }
    })

    col.find().toArray(function (err,rest) {
        console.log(rest)
    })




}