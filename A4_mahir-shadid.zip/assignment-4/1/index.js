var exp = require('express')
var bp = require('body-parser')
var mul = require('multer')
var mul = mul()
app=exp()
app.use(bp.json())
app.use(mul.array())
app.use(exp.static('public'))
app.post('/',function (req,res) {
    
    // lets take a demo nogod account

    //header properties
    let phone= req.header('phoneNumber')
    let pin= req.header('PIN')
    //phoneNumber = 01888504938
    //PIN = 1234

    //URL QUERY
    let nid= req.query.nid
    let name= req.query.Name
    let age= req.query.Age
    let bd= req.query.birthYear
    //http://localhost:8000?nid=555701&Name=Mahir&Age=22&birthYear=1999

    //body
    let jdata = req.body
    let jstr = JSON.stringify(jdata)
    let jname = jdata['NID']['Name']
    let jphone = jdata['Phone']
    /*{
        "PIN":"1234",
        "Phone":"01888504938",
        "NID":{
            "Name":"Mahir",
            "Age":"22",
            "BirthYear : 1999":{
                "Date":"06",
                "Month":"11"
            }
        }
    }*/


    res.send("Header: \n\n"+"Phone: "+phone+"\nPIN: "+pin+
        "\n\nQUERY:\n\nNID: "+nid+"\nName: "+name+"\nAge: "+age+"\nBirthYear: "+bd+
        "\n\nBODY:"+jstr+
        "\n\nName from Json RAW Body: "+jname+
        "\nPhone from Json RAW Body: "+jphone)
})

app.listen(8000,function () {
    console.log("server connected")
})

/* ########### output:

***********when Body is RAW Json:

Header: 

Phone: 01888504938
PIN: 1234

QUERY:

NID: undefined
Name: Mahir
Age: 22
BirthYear: 1999

BODY:{"PIN":"1234","Phone":"01888504938","NID":{"Name":"Mahir","Age":"22","BirthYear : 1999":{"Date":"06","Month":"11"}}}

Name from Json RAW Body: Mahir
Phone from Json RAW Body: 01888504938

*********when Body is in Multiple Form Data:

Header: 

Phone: 01888504938
PIN: 1234

QUERY:

NID: undefined
Name: Mahir
Age: 22
BirthYear: 1999

BODY:{"NID":"555701","Phone":"01888504938"}

Name from Json RAW Body: undefined
Phone from Json RAW Body: 01888504938 

*/