var exp = require('express')
var mul = require('multer')

app=exp()

var store = mul.diskStorage(
    {
        destination: function (req,file,callback) {

            callback(null,"./upload")
            
        },
        filename: function (req,file,callback) {
            
            callback(null,file.originalname)

        }
    }
)

var upload = mul({storage:store}).array('file',2) //for 1 jpg and 1 png
app.post('/',function (req,res) {
    upload(req,res,function (err) {
        if(err){

            res.send("Upload Failed")

        }else{

            res.send("Upload success!")
        }
    })
})

// in the form-data, key is the 'file' in array function and
// i have selected a .jpg and a .png file, upload was a succes

app.listen(8000,function () {
    console.log("server connected")
})