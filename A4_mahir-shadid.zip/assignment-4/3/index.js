var exp = require('express')
//var mul = require('multer')
app=exp()
var folderPath = __dirname+'/download_from' //application diretory
//below get method downloads a covid logo from the app directory
app.get('/',function(req,res) {   
    res.download(folderPath+'/logo.jpg', function(err) {
        if(err) {
            console.log(err);
        }
    })
})

app.listen(8000,function () {
    console.log("server connected")
})