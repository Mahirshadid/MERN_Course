const app = require("./app");

app.listen(5536,function () {
    console.log("index worked")
})