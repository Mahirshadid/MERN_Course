const exp = require('express')
const route = exp.Router()
const controller = require("E:/MERN/Mongoose_Query_Project/src/controllers/empcontroller.js")
route.post("/insertemployee",controller.InsertData)
route.post("/loginemployee",controller.empLogin)
route.post("/changepass",controller.changePass)
module.exports=route