const empmodel = require("../../empmodel")

//REGISTRATION PART of the assignment

exports.InsertData=(req,res)=>{

    let reqbody = req.body 

    empmodel.create(reqbody,(error,data)=>{
        if(error){
            res.status(400).json({status:"Failed",data:error})
        }else{
            res.status(200).json({status:"Success",data:data})
        }
    })

}

//LOGIN PART of the assignment

exports.empLogin=(req,res)=>{

    let reqbody = req.body 

    var username = reqbody.username
    var password = reqbody.password


    empmodel.findOne({username:username,password:password},(error,data)=>{
        if(error){
            res.status(400).json({status:"Failed",data:error})
        }else if(!data){
            res.status(404).json({status:"Not found",data:null})
        }else{
            res.status(200).json({status:"Logged In",data:data})
        }
    })
}

//Password Changing PART of the assignment

exports.changePass=(req,res)=>{

    let reqbody = req.body 

    var username = reqbody.username
    var password = reqbody.password


    empmodel.updateOne({username:username},{$set:{password:password}},(error,data)=>{
        if(error){
            res.status(400).json({status:"Failed",data:error})
        }else{
            res.status(200).json({status:"Changed",data:data})
        }
    })
}
