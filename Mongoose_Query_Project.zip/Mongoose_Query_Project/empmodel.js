const mongoose = require("mongoose")

const dataschema = mongoose.Schema({

    username:String,
    password:String

})

const empmodel = mongoose.model('employee',dataschema)
module.exports=empmodel