const exp = require("express")
const bp = require("body-parser")
const app = new exp()
const mongoose = require("mongoose")
const route = require('./src/routes/api')
const express = require("express")
app.use(express.json())
app.use(express.urlencoded({extended:false}))
let uri = "mongodb://127.0.0.1:27017/attendance"
let opt = {user:'',pass:''}

mongoose.connect(uri,opt,(error)=>{
    console.log("Con-Success")
    console.log(error)
})
app.use("/api",route)
module.exports=app