let carlist=[
    {brand: 'Toyota',price:'2000k',condition:'good'},
    {brand: 'Nissan',price:'3000k',condition:'bad'},
    {brand: 'BMW',price:'14000k',condition:'rusty'},
    {brand: 'Mercedes',price:'25000k',condition:'good'},
    {brand: 'Suzuki',price:'800k',condition:'poor'},
    {brand: 'Proton',price:'600k',condition:'poor'},
    {brand: 'PHP Automobiles',price:'400k',condition:'excellent'},
    {brand: 'Bajaj',price:'500k',condition:'good'},
]

let carwithnest=[
    {carb:{model:'Suzuki Alto',condition:'very rusty',engine:'changed'}
    ,priceDecrese: "10k"}

]

export {carlist,carwithnest};