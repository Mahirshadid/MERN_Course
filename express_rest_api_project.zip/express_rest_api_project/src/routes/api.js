const exp = require('express')
const route = exp.Router()
const controller1 = require("E:/MERN/express_rest_api_project/src/controllers/controller1")
route.get("/helloget",controller1.Hello)
route.post("/hellopost",controller1.Hello)

module.exports=route