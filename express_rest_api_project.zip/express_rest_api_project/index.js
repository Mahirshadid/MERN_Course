const app = require("E:/MERN/express_rest_api_project/app");
const dotenv = require("dotenv")
dotenv.config({path:'./config.env'})
app.listen(process.env.RUNNING_PORT,function () {
    console.log("From ENV "+"OK "+process.env.RUNNING_PORT)
})