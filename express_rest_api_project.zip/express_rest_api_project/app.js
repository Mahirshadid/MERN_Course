const exp = require('express')
const route = require('./src/routes/api')
const app = new exp()

//undefined route

//app.use('*',(req,res)=>{
//   res.status(404).json({status:"Fail",data:"Not Found"})
//})

//middlewares - securities

//const erl = require("express-rate-limit")
const helmet = require("helmet")
const ems = require("express-mongo-sanitize")
const hpp = require("hpp")
const cors = require("cors")

app.use(helmet())
app.use(ems())
app.use(hpp())
app.use(cors())


app.use("/api/v",route)
module.exports=app